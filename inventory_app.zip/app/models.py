from . import db
from datetime import datetime

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ean = db.Column(db.String(50), unique=True, nullable=False)
    product_code = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(200), nullable=False)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)

class InventorySheet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    items = db.relationship('InventoryItem', backref='sheet', lazy=True, cascade="all, delete-orphan")

class InventoryItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_code = db.Column(db.String(50), db.ForeignKey('product.product_code'), nullable=False)
    expected_quantity = db.Column(db.Integer, nullable=False, default=0)
    actual_quantity = db.Column(db.Integer, nullable=False, default=0)
    sheet_id = db.Column(db.Integer, db.ForeignKey('inventory_sheet.id'), nullable=False)
    product = db.relationship('Product')

class ScanLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    user_name = db.Column(db.String(100), db.ForeignKey('user.name'), nullable=False)
    product_code = db.Column(db.String(50), db.ForeignKey('product.product_code'), nullable=False)
    user = db.relationship('User')
    product = db.relationship('Product')
