# Aplikacja Inwentaryzacyjna
1. `pip install -r requirements.txt`
2. `python3 run.py`
3. Wejdź na `http://<IP_SERWERA>:5000`
