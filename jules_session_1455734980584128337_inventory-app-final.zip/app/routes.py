from flask import render_template, request, redirect, url_for, flash, Response, session
from werkzeug.utils import secure_filename
from app import db
from app.models import User, Product, InventorySheet, InventoryItem, ScanLog
import csv
import io
import zipfile
from datetime import datetime
from flask import current_app as app
from functools import wraps
from sqlalchemy import or_

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('user_login'))
        return f(*args, **kwargs)
    return decorated_function

@app.context_processor
def inject_user():
    user_id = session.get('user_id')
    if user_id:
        return dict(current_user=User.query.get(user_id))
    return dict(current_user=None)

@app.route('/')
def index():
    return redirect(url_for('user_login'))

@app.route('/login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        if user_id:
            user = User.query.get(user_id)
            session['user_id'] = user.id
            session['user_name'] = user.name
            return redirect(url_for('user_dashboard'))
    if 'user_id' in session:
        return redirect(url_for('user_dashboard'))
    return render_template('user_login.html', users=User.query.all())

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('user_login'))

@app.route('/dashboard')
@login_required
def user_dashboard():
    return render_template('user_dashboard.html')

@app.route('/scan/free', methods=['GET', 'POST'])
@login_required
def scan_free_mode():
    if request.method == 'POST':
        scan_input = request.form.get('scan_input', '').strip()
        if not scan_input:
            flash("Proszę podać kod.", "error")
        else:
            product = Product.query.filter(or_(Product.ean == scan_input, Product.product_code == scan_input)).first()
            if not product:
                flash(f"Produkt o kodzie '{scan_input}' nie istnieje.", "error")
            else:
                item = InventoryItem.query.filter_by(product_code=product.product_code).first()
                if not item:
                    sheet = InventorySheet.query.filter_by(name="nieznana lista").first()
                    if not sheet:
                        sheet = InventorySheet(name="nieznana lista")
                        db.session.add(sheet)
                        db.session.flush()
                    item = InventoryItem(product_code=product.product_code, sheet_id=sheet.id)
                    db.session.add(item)
                item.actual_quantity += 1
                db.session.add(ScanLog(user_name=session['user_name'], product_code=product.product_code))
                db.session.commit()
                flash(f"Zeskanowano: {product.name}", "success")
        return redirect(url_for('scan_free_mode'))
    return render_template('scan_free_mode.html')

@app.route('/scan/sheets')
@login_required
def select_sheet_list():
    return render_template('select_sheet_list.html', sheets=InventorySheet.query.all())

@app.route('/scan/sheet/<int:sheet_id>', methods=['GET', 'POST'])
@login_required
def scan_sheet_mode(sheet_id):
    sheet = InventorySheet.query.get_or_404(sheet_id)
    if request.method == 'POST':
        scan_input = request.form.get('scan_input', '').strip()
        product = Product.query.filter(or_(Product.ean == scan_input, Product.product_code == scan_input)).first() if scan_input else None
        if not product:
            flash(f"Produkt o kodzie '{scan_input}' nie istnieje.", "error")
        else:
            item = InventoryItem.query.filter_by(sheet_id=sheet_id, product_code=product.product_code).first()
            if not item:
                flash(f"Produkt '{product.name}' nie jest na tej liście.", "error")
            else:
                item.actual_quantity += 1
                db.session.add(ScanLog(user_name=session['user_name'], product_code=product.product_code))
                db.session.commit()
                flash(f"Zeskanowano: {product.name}", "success")
        return redirect(url_for('scan_sheet_mode', sheet_id=sheet_id))
    
    q = request.args.get('q', '')
    items_query = sheet.items
    if q:
        items_query = [item for item in items_query if q.lower() in item.product.name.lower() or q.lower() in item.product.product_code.lower()]
    
    return render_template('scan_sheet_mode.html', sheet=sheet, items=items_query, scanned_count=sum(1 for i in sheet.items if i.actual_quantity > 0))

@app.route('/scan/item/<int:item_id>/edit', methods=['POST'])
@login_required
def manual_edit_item(item_id):
    item = InventoryItem.query.get_or_404(item_id)
    try:
        item.actual_quantity = int(request.form.get('new_quantity', 0))
        db.session.commit()
        flash("Ilość zaktualizowana.", "success")
    except (ValueError, TypeError):
        flash("Nieprawidłowa ilość.", "error")
    return redirect(url_for('scan_sheet_mode', sheet_id=item.sheet_id))

@app.route('/admin')
def admin_index(): return render_template('admin_index.html')

@app.route('/admin/users', methods=['GET', 'POST'])
def admin_users():
    if request.method == 'POST':
        name = request.form.get('name')
        if name and not User.query.filter_by(name=name).first():
            db.session.add(User(name=name))
            db.session.commit()
    return render_template('admin_users.html', users=User.query.all())

@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('admin_users'))

@app.route('/admin/products', methods=['GET', 'POST'])
def admin_products():
    if request.method == 'POST':
        file = request.files.get('file')
        if file and file.filename.endswith('.csv'):
            reader = csv.reader(io.StringIO(file.read().decode('utf-8')), delimiter=';')
            for ean, code, name in reader:
                if not Product.query.filter_by(product_code=code).first():
                    db.session.add(Product(ean=ean, product_code=code, name=name))
            db.session.commit()
    return render_template('admin_products.html', products=Product.query.all())

@app.route('/admin/inventory-sheets', methods=['GET', 'POST'])
def admin_inventory_sheets():
    if request.method == 'POST':
        file = request.files.get('file')
        name = request.form.get('sheet_name')
        if file and name and not InventorySheet.query.filter_by(name=name).first():
            sheet = InventorySheet(name=name)
            db.session.add(sheet)
            db.session.flush()
            reader = csv.reader(io.StringIO(file.read().decode('utf-8')), delimiter=';')
            for code, qty in reader:
                if Product.query.filter_by(product_code=code).first():
                    db.session.add(InventoryItem(product_code=code, expected_quantity=int(qty), sheet_id=sheet.id))
            db.session.commit()
    return render_template('admin_inventory_sheets.html', sheets=InventorySheet.query.all())

@app.route('/admin/inventory-sheets/delete/<int:sheet_id>', methods=['POST'])
def delete_inventory_sheet(sheet_id):
    sheet = InventorySheet.query.get_or_404(sheet_id)
    db.session.delete(sheet)
    db.session.commit()
    return redirect(url_for('admin_inventory_sheets'))

@app.route('/admin/work-report')
def admin_work_report():
    return render_template('admin_work_report.html', logs=ScanLog.query.order_by(ScanLog.timestamp.desc()).all())

@app.route('/admin/work-report/export-csv')
def export_work_report_csv():
    output = io.StringIO()
    writer = csv.writer(output, delimiter=';')
    writer.writerow(['Timestamp', 'User', 'Product Code', 'Product Name'])
    for log in ScanLog.query.order_by(ScanLog.timestamp.desc()).all():
        writer.writerow([log.timestamp, log.user_name, log.product.product_code, log.product.name])
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition":"attachment;filename=work_report.csv"})

@app.route('/admin/export')
def admin_export(): return render_template('admin_export.html')

@app.route('/admin/export/zip')
def export_all_sheets_zip():
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w') as zf:
        for sheet in InventorySheet.query.all():
            output = io.StringIO()
            writer = csv.writer(output, delimiter=';')
            writer.writerow(['kod produktu', 'nazwa', 'ilość oczekiwana', 'ilość rzeczywista'])
            for item in sheet.items:
                writer.writerow([item.product.product_code, item.product.name, item.expected_quantity, item.actual_quantity])
            zf.writestr(f"{secure_filename(sheet.name)}.csv", output.getvalue())
    memory_file.seek(0)
    return Response(memory_file, mimetype='application/zip', headers={'Content-Disposition': 'attachment;filename=inventory.zip'})
